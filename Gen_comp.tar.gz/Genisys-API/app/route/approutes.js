'use strict';
module.exports = function(app) {
  var todoList = require('../controller/appController');
  var transactionList = require('../controller/transactionController');

  // todoList Routes
  app.route('/tasks')
    .get(todoList.list_all_tasks)
    .post(todoList.create_a_task);
   
   app.route('/tasks/:taskId')
    .get(todoList.read_a_task)
    .put(todoList.update_a_task)
    .delete(todoList.delete_a_task);

    app.route('/tasks/notification')
    .get(todoList.getNotification)
    .post(todoList.create_a_task);


  app.route('/transaction')
    .get(transactionList.list_all_transaction)
    .post(transactionList.create_a_transaction);
   
   app.route('/transaction/:transactionId')
    .get(transactionList.read_a_transaction)
    .put(transactionList.update_a_transaction)
    .delete(transactionList.delete_a_transaction);
    };
