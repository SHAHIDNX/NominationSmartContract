'use strict';
var opn = require('opn');

var Task = require('../model/transactionModel');

exports.list_all_transaction = function(req, res) {
  Task.getAllTask(function(err, task) {

    console.log('controller')
    if (err)
      res.send(err);
      console.log('res', task);
    res.send(task);
  });
};



exports.create_a_transaction = function(req, res) {
  var new_task = new Task(req.body);
  //handles null error 
   if(!new_task.hash ){

            res.status(400).send({ error:true, message: 'Please provide hash' });

        }
else{
  
  Task.createTask(new_task, function(err, task) {
    
    if (err)
      res.send(err);
    res.json(task);
  });
}
};


exports.read_a_transaction = function(req, res) {
    console.log("::::::::::",req.params)
  Task.getTaskById(req.params.transactionId, function(err, task) {
    if (err){
        res.send(err);
    }else{
        trans(task[0].hash);
        //res.redirect('https://app.example.io');
        //res.status(301).redirect("https://www.google.com")
      res.json(task);
    }
  });
};

exports.update_a_transaction = function(req, res) {
    Task.updateById(req.params.taskId, new Task(req.body), function(err, task) {
      if (err)
        res.send(err);
      res.json(task);
    });
  };
  
  
  exports.delete_a_transaction = function(req, res) {
  
  
    Task.remove( req.params.taskId, function(err, task) {
      if (err)
        res.send(err);
      res.json({ message: 'Task successfully deleted' });
    });
  };



  function trans(x){
    let hash = '0x92884f859ada602c082c94ac7063aa229b97f193382e58cb7110817320b582c2';
    var Web3 = require('web3');
    
    let web3 = new Web3(new Web3.providers.HttpProvider('https://ropsten.infura.io/8e7e5f3ed7414b8eabb189c0586963d5'));
    //var ethTx = ('0x92884f855ada602c082c94ac7063aa229b97f193382e58cb7110817320b582c2');
    var ethTx = (x);
    web3.eth.getTransactionReceipt(ethTx, function(err, result) {
        console.log(result,"============res")
        if(result){
          //window.location.replace('https://foundry376.zendesk.com/hc/en-us/articles/115003228391-How-can-I-get-a-payment-receipt-for-my-subscription-')
            console.log("redirect---page");

            (async () => {
             
              // Specify the app to open in
              await opn('https://www.npmjs.com/package/opn', {app: 'firefox'});
           
              // Specify app arguments
              //await opn('https://sindresorhus.com', {app: ['google chrome', '--incognito']});
          })();

            
            //result.redirect('https://app.example.io');

            console.log("===========================")


        }else{
            console.log("wait")
        }
        //    if (!err) {
        //            console.log('From Address: ' + result.from);
        //            console.log('To Address: ' + result.to);
        //            console.log('Blocknumebr: ' + result.blockNumber);
        //            console.log('status: ' + result.status);
    
        //    }
        //    else {
        //            console.log('Error!', err);
        //    }
    });
  }