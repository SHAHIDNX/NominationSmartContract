'use strict';

var Task = require('../model/appModel.js');

exports.list_all_tasks = function(req, res) {
  // Task.getAllTask(function(err, task) {

  //   console.log('controller')
  //   if (err)
  //     res.send(err);
  //     console.log('res', task);
  //   res.send(task);
  // });


  var new_task = new Task(req.query);
  console.log(new_task,"====")
    //handles null error 
     if(!new_task.token){
  
              res.status(400).send({ error:true, message: 'Please provide token' });
  
          }
  else{
    
    Task.createTask(new_task, function(err, task) {
      
      if (err)
        res.send(err);
      res.json(task);
    });
  }




};


exports.getNotification = function(req, res) {
    Task.getNotification(function(err, task) {
  
      console.log('controller')
      if (err)
        res.send(err);
        console.log('res', task);
      res.send(task);
    });
  };



exports.create_a_task = function(req, res) {
  var new_task = new Task(req.body);
console.log(new_task,"====")
  //handles null error 
   if(!new_task.token){

            res.status(400).send({ error:true, message: 'Please provide token' });

        }
else{
  
  Task.createTask(new_task, function(err, task) {
    
    if (err)
      res.send(err);
    res.json(task);
  });
}
};


exports.read_a_task = function(req, res) {
  Task.getTaskById(req.params.taskId, function(err, task) {
    if (err){
        res.send(err);
    }else{
        console.log(task[0].token,"============>")
        notification(task[0].token);
        //trans();
        res.json(task);
    }
  });
};

exports.update_a_task = function(req, res) {
    Task.updateById(req.params.taskId, new Task(req.body), function(err, task) {
      if (err)
        res.send(err);
      res.json(task);
    });
  };
  
  
  exports.delete_a_task = function(req, res) {
  
  
    Task.remove( req.params.taskId, function(err, task) {
      if (err)
        res.send(err);
      res.json({ message: 'Task successfully deleted' });
    });
  };



  function notification(token){
    
      var FCM = require('fcm-node');
      var serverKey = 'AAAA5_3L2fc:APA91bHMmk_2DMuuSgGrLMi52t05Pe2O5L8rDwlyrlho1UJS9r7QSgVsqmdzJTqMweMbiuWmBDe5opoKcjv10byAdmFoxWnRtVBbAYWRJrRz5Mq4ZxfPhWFvikp02Y-d4No40eTNESxd';
      //var serverKey = 'AAAAExg2Qeg:APA91bE_fIrCt2PtVRaVlYulH2nWXHaleg5H5bwf3cXukz3NE3R3F2esrbrkfiFCbh0IqFnXgsgERZChh7gEWSh57Huco0Ew0zkPuBlTb1Kx29WKO-XNuPrRb7VrDG4LWgMc4nuGiPAE'; //put your server key here
      var fcm = new FCM(serverKey);
    
       var message = { //this may vary according to the message type (single recipient, multicast, topic, et cetera)
          // to: 'dwYKINksfw0:APA91bEy9KurJL0-o5Sh-pG1wnoY0CH6-HPYclwdZMWcOwDbuHsDa2xkovyMCHthXmE9xhKH_WFKX_Gz-zyxuZP3JqBncncBQlMvkjDt29-qhIhBp68IK97LQ6VShbOjKdKKj5893q2v', 
       //to:'fN6D59rKROg:APA91bETcX3-61SauWXM_VvhnUVZSUc8oRo5bsdAAsfTEknT4I8X7kzg-VbW8nrvVafJz1G9GeJ4rKcKABvhJdncDzSUcAaxmzGnQuyH1Qbi03xiFs-U8LjSa_7VgtV9KRaNQu5waLdj',
   
        //to:'d3jLktleKh4:APA91bF4zHzqaLRbgUo_x4odcXkRwhcW_OwZrw4vRKEJSrh8c2fny58mnnlyeCgukwxdAjpbVf__dNu-WPjbj-JudD-5fD8ESClncyVwL-VDPimbjqSmHQdHyF7JQ1i6m1dOdbNcwmVF', 
         to:token,
         notification: {
                      title: 'Genisys Wallet', 
                      body: '{"name" : "SHOPPING EKART SERVICES PAYMENT REQUEST","product_id" : "123","final_price" : "0.00035"}',
          click_action:"android.intent.action.PAY" 
                  },
                  
                  data: {  //you can send only notification or only data(or include both)
                      title: 'Genisys Wallet', 
                      body: '{"name" : "LG LED TV S15","product_id" : "123","final_price" : "0.00035"}'
                  }
                  
       };
       
       fcm.send(message, function(err, response){
           if (err) {
               console.log("Something has gone wrong!");
           } else {
               console.log("Successfully sent with response: ", response);
           }
       });
   
   
      
  }


//   function trans(x){
//     let hash = '0x92884f855ada602c082c94ac7063aa229b97f193382e58cb7110817320b582c2';
//     var Web3 = require('web3');
    
//     let web3 = new Web3(new Web3.providers.HttpProvider('https://ropsten.infura.io/8e7e5f3ed7414b8eabb189c0586963d5'));
//     //var ethTx = ('0x92884f855ada602c082c94ac7063aa229b97f193382e58cb7110817320b582c2');
//     var ethTx = (hash);
//     web3.eth.getTransactionReceipt(ethTx, function(err, result) {
//            if (!err) {
//                    console.log('From Address: ' + result.from);
//                    console.log('To Address: ' + result.to);
//                    console.log('Blocknumebr: ' + result.blockNumber);
//                    console.log('status: ' + result.status);
    
//            }
//            else {
//                    console.log('Error!', err);
//            }
//     });
//   }