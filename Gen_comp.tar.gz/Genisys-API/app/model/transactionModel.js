'user strict';
var sql = require('./db.js');

//Transaction object constructor
var Transaction = function(transaction){
    this.hash = transaction.task;
    this.transactionId = transaction.transactionId;
    this.status = transaction.status;
    this.created_at = new Date();
};
Transaction.createTask = function (newTask, result) {    
        sql.query("INSERT INTO transaction set ?", newTask, function (err, res) {
                
                if(err) {
                    console.log("error: ", err);
                    result(err, null);
                }
                else{
                    console.log(res.insertId);
                    result(null, res.insertId);
                }
            });           
};
Transaction.getTaskById = function (taskId, result) {
    console.log(taskId,"===========::::")
    sql.query("Select hash from transaction where id = ? ", taskId, function (err, res) {             
                if(err) {
                    console.log("error: ", err);
                    result(err, null);
                }
                else{
                    result(null, res);
              
                }
            });   
};
Transaction.getAllTask = function (result) {
        sql.query("Select * from transaction", function (err, res) {

                if(err) {
                    console.log("error: ", err);
                    result(null, err);
                }
                else{
                  console.log('tasks : ', res);  

                 result(null, res);
                }
            });   
};




Transaction.updateById = function(id, task, result){
  sql.query("UPDATE transaction SET hash = ? WHERE id = ?", [transaction.task, id], function (err, res) {
          if(err) {
              console.log("error: ", err);
                result(null, err);
             }
           else{   
             result(null, res);
                }
            }); 
};
Transaction.remove = function(id, result){
     sql.query("DELETE FROM transaction WHERE id = ?", [id], function (err, res) {

                if(err) {
                    console.log("error: ", err);
                    result(null, err);
                }
                else{
               
                 result(null, res);
                }
            }); 
};

module.exports= Transaction;